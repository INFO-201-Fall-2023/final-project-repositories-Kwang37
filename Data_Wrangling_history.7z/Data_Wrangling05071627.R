library(dplyr)
library(stringr)
library(testthat)
library(ggplot2)

subscribed_df_origin <- read.csv("H:/INFO201/FINAL/topSubscribed.csv")

subscribed_df <- read.csv("H:/INFO201/FINAL/topSubscribed.csv")
videos_df <- read.csv("H:/INFO201/FINAL/CAvideos.csv")


videos_df <- select(videos_df, channel_title, views, category_id)
subscribed_df <- select(subscribed_df, Youtube.Channel, Video.Views, Category, Video.Count)

#Since there are some lines contain "0", we first clean these lines in subscribed_df
subscribed_df <- subset(subscribed_df, Video.Count != 0)

# After cleaning these line, we face the second question. 
# One dataset is containing the channel as whole, while another is aboue each 
# single video. So we decide to add a new column called "performance" to 
# Find the average number of play of each video for each Youtuber.

performance <- vector("numeric", length = nrow(subscribed_df))

#subscribed_df$views <- as.numeric(subscribed_df$Video.Views)
# There are also datas contain the mark "," in the numbers, to deal with it,
# We use the gsub function to remove the "," within the column
# We also use as.numeric to deal with the strings...

subscribed_df[,2] <- gsub(",", "", subscribed_df[,2])
subscribed_df[,4] <- gsub(",", "", subscribed_df[,4])

subscribed_df[,2] <- as.numeric(subscribed_df[,2])
subscribed_df[,4] <- as.numeric(subscribed_df[,4])

i <- 1

while(i < nrow(subscribed_df)){
  
  performance[i] = subscribed_df[i,2] / subscribed_df[i,4]
  
  i <- i + 1
  
}

subscribed_df$views <- performance

# Yet, in the most popular videos, we may also see Youtuber with high subscribed
# numbers also in the list of top subscribers, so we add a new feature 
subscribed_df$Channel.Video <- "Channel"
videos_df$Channel.Video <- "Video"

# Converting the categories in video_df into the characters
# The meaning behind the numbers is provided in the json file of the uploader

videos_df <- videos_df %>% mutate(category_id = case_when(
  
  category_id == 2 ~ "Autos & Vehicles",
  category_id == 10 ~ "Music",
  category_id == 15 ~ "Pets & Animals",
  category_id == 17 ~ "Sports",
  category_id == 18 ~ "Short Movies",
  category_id == 19 ~ "Travel & Events",
  category_id == 20 ~ "Gaming",
  category_id == 21 ~ "Videoblogging",
  category_id == 22 ~ "People & Blogs",
  category_id == 23 ~ "Comedy",
  category_id == 24 ~ "Entertainment",
  category_id == 25 ~ "News & Politics",
  category_id == 26 ~ "Howto & Style",
  category_id == 27 ~ "Education",
  category_id == 28 ~ "Science & Technology",
  category_id == 30 ~ "Movies",
  category_id == 31 ~ "Anime/Animation",
  category_id == 32 ~ "Action/Adventure",
  category_id == 33 ~ "Classics",
  category_id == 34 ~ "Comedy",
  category_id == 35 ~ "Documentary",
  category_id == 36 ~ "Drama",
  category_id == 37 ~ "Family",
  category_id == 38 ~ "Foreign",
  category_id == 39 ~ "Horror",
  category_id == 40 ~ "Sci-Fi/Fantasy",
  category_id == 41 ~ "Thriller",
  category_id == 42 ~ "Shorts",
  category_id == 43 ~ "Shows",
  category_id == 44 ~ "Trailers",
  
  ))

# Yet, we see see many NAs in this column
# So we would remove these lines with NA

videos_df <- filter(videos_df, !is.na(videos_df$category_id))

# So far, the videos_df is cleaned and ready to be merge
# But we need to remove the irrelevent line in subscribed_df 

subscribed_df <- select(subscribed_df,Youtube.Channel,Category,views,Channel.Video)

#Now they have same number of roles
#But we still need to change name of each column to use Rbind

names(subscribed_df)[1] <- "channel_title"
names(subscribed_df)[2] <- "category"
names(videos_df)[3] <- "category"

# Lastly I remove some lines in youtube_df to make it only contains 25000 lines in total
videos_df <- head(videos_df, -15000)

youtube_df <- rbind(videos_df, subscribed_df)

#write.csv(youtube_df, file = "youtube_df.csv", row.names = FALSE)

# Now, I will try to find what is the most popular topic 
# To do so, we need to find the rate of transform and the total number of subscriber
# These two line of codes will remove an error line, and the ones with zero videos.
subscribed_df_origin <- subset(subscribed_df_origin, Video.Count != 0)
subscribed_df_origin <- filter(subscribed_df_origin, subscribed_df_origin$Category != "https://us.youtubers.me/global/all/top-1000-most_subscribed-youtube-channels")


# This part will create a line of categories, and turn the string into numbers
sentences <- c("Autos & Vehicles", "Music", "15 Pets & Animals", "17 Sports", "18 Short Movies", "19 Travel & Events", "20 Gaming", "21 Videoblogging", "22 People & Blogs", "23 Comedy", "24 Entertainment", "25 News & Politics", "26 Howto & Style", "27 Education", "28 Science & Technology", "30 Movies", "31 Anime/Animation", "32 Action/Adventure", "33 Classics", "34 Comedy", "35 Documentary", "36 Drama", "37 Family", "38 Foreign", "39 Horror", "40 Sci-Fi/Fantasy", "41 Thriller", "42 Shorts", "43 Shows", "44 Trailers")

sentences_without_numbers <- gsub("\\d", "", sentences)

subscribed_df_origin[,3] <- gsub(",", "", subscribed_df_origin[,3])
subscribed_df_origin[,3] <- as.numeric(subscribed_df_origin[,3])

subscribed_df_origin[,4] <- gsub(",", "", subscribed_df_origin[,4])
subscribed_df_origin[,4] <- as.numeric(subscribed_df_origin[,4])

#This line of code will calculate the rate of transform, which can used to represent how attractive a topic is.
subscribed_df_origin$Transform <- subscribed_df_origin$Subscribers / subscribed_df_origin$Video.Views

# Now we get the subscribed_df_origin we need, containing trasform rate. 
# But we also found some accounts have errors in the transfrom rate extremely high. 

sd_trans <- sd(subscribed_df_origin$Transform)

Q1 <- quantile(subscribed_df_origin$Transform, 0.25)
Q3 <- quantile(subscribed_df_origin$Transform, 0.75)
IQR <- Q3 - Q1
lower_fence <- Q1 - 1.5 * IQR
upper_fence <- Q3 + 1.5 * IQR

# Identify outliers and remove them...
subscribed_df_origin <- filter(subscribed_df_origin,subscribed_df_origin$Transform < upper_fence)
subscribed_df_origin <- filter(subscribed_df_origin,subscribed_df_origin$Transform > lower_fence)

# Now we have a dataset with transfrom rate
# Now we are going to calculate the average subscriber of each categories

subscribers_by_category <- aggregate(Subscribers ~ Category, data = subscribed_df_origin, FUN = mean)

# Now we are going to calculate the average transform rate of each categories

subscribers_by_transform <- aggregate(Transform ~ Category, data = subscribed_df_origin, FUN = mean)

#By now, we merge the data about transform rate and subscrption together
category_avg <- merge(subscribers_by_category,subscribers_by_transform,by = "Category")

# Now we can find the relationship between topic and subscribers

category_avg$Category <- reorder(category_avg$Category , category_avg$Subscribers)

cat_sub_plot <- ggplot(data = category_avg, aes(x = Subscribers, y = Category, color = Category)) +
  geom_point() + ylab("Category of the video") + xlab("Number of subscribers")

cat_sub_plot

category_avg$Category<- reorder(category_avg$Category, category_avg$Transform)

transform_plot <- ggplot(data = category_avg, aes(x = Transform , y = Category, color = Category)) +
  geom_point() + ylab("Category of the video") + xlab("Rate of transform")

transform_plot

plot <- ggplot(data = category_avg, aes(x = Subscribers, y = Transform, color = Category)) + geom_point()

plot

# Yet, all these above only shows the top subscibed channels, what if we take a look in real day data ?

views_by_category <- aggregate(views ~ category, data = videos_df, FUN = mean)

views_by_category$category<- reorder(views_by_category$category, views_by_category$views)

video_plot <- ggplot(data = views_by_category, aes(x = views , y = category, color = category)) +
  geom_point() + xlab("AVG views of the video") + ylab("Categories of video")

video_plot 
